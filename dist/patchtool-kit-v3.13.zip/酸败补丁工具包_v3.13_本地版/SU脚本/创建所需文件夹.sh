#!/system/bin/sh
# ============================================================
# 酸败补丁 · 目录初始化（v3.13，对齐 APP v3.12）
#
# 只做一件事：把 APP 和 SU 脚本共用的目录一次建齐。
# 目录清单与 APP 的 rootStr 结构一致，多加了 缓存/资源索引（CAB 索引用）。
# 全部用 POSIX 循环，/system/bin/sh（mksh）可直接跑。
# ============================================================

VERSION="SU 目录初始化 v3.13（对齐 APP v3.12）"
MAIN_PUB="/storage/emulated/0/LvShu/酸败补丁"
NO_ELEVATE=0

usage() {
    cat <<EOF
$VERSION

用法：
  sh 创建所需文件夹.sh [选项]

选项：
  --no-elevate   已经是 root / 调试用，不再自己调 su
  -h, --help     显示本帮助
EOF
}

while [ $# -gt 0 ]; do
    case "$1" in
        --no-elevate) NO_ELEVATE=1; shift ;;
        -h|--help)    usage; exit 0 ;;
        *)
            echo "✗ 不认识的参数：$1"
            usage
            exit 1
            ;;
    esac
done

# ---------- 自提权 ----------
if [ "$(id -u)" != "0" ] && [ "$NO_ELEVATE" != "1" ]; then
    case "$0" in
        *"'"*)
            echo "✗ 脚本路径里含单引号，su 提权无法安全引用；请把脚本放到普通路径后重试"
            exit 1
            ;;
    esac
    exec su -c "sh '$0'"
fi

echo "=== $VERSION ==="
echo "根目录：$MAIN_PUB"
echo "身份：uid=$(id -u)"

FAIL=0
CREATED=0
for DIR in \
    "$MAIN_PUB" \
    "$MAIN_PUB/补丁存放位置（zip）" \
    "$MAIN_PUB/临时解压" \
    "$MAIN_PUB/操作日志" \
    "$MAIN_PUB/备份文件" \
    "$MAIN_PUB/备份文件/原版" \
    "$MAIN_PUB/补丁素材源文件" \
    "$MAIN_PUB/打包补丁" \
    "$MAIN_PUB/打包补丁/待打包资源" \
    "$MAIN_PUB/缓存" \
    "$MAIN_PUB/缓存/资源索引"
do
    if [ -d "$DIR" ]; then
        echo "- 已存在 $DIR"
    elif mkdir -p "$DIR" 2>/dev/null; then
        CREATED=$((CREATED+1))
        echo "✓ 新建 $DIR"
    else
        FAIL=$((FAIL+1))
        echo "✗ 无法创建 $DIR"
        continue
    fi
    chmod 0775 "$DIR" 2>/dev/null
    command -v restorecon >/dev/null 2>&1 && restorecon "$DIR" >/dev/null 2>&1
done

echo "=== 验证 ==="
ls -ld "$MAIN_PUB"/* 2>/dev/null

echo ""
if [ "$FAIL" -eq 0 ]; then
    echo "全部目录已就绪（本次新建 $CREATED 个）。"
    echo "下一步：把补丁 zip 放进「补丁存放位置（zip）」，再跑 自动安装补丁.sh。"
else
    echo "有 $FAIL 个目录没建成，检查上面 ✗ 的项。"
fi

if [ -t 0 ]; then
    echo "按回车关闭终端..."
    read -r _
fi

[ "$FAIL" -eq 0 ] && exit 0
exit 1