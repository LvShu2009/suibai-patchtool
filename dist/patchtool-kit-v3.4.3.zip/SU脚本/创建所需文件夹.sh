#!/system/bin/sh
# ============================================================
# 酸败补丁 · 目录初始化（修订版 v2）
# 原始版用了 bash 数组 DIRS_TO_CREATE=(...)，/system/bin/sh 是 mksh，
# 会直接语法报错 —— 这里改成 POSIX 循环，任何 sh 都能跑。
# 权限模型不变：su 驱动（普通用户跑也能建，只是某些目录需要 root）。
# ============================================================

MAIN_DIR="/storage/emulated/0/LvShu/酸败补丁"

if [ "$(id -u)" != "0" ]; then
    exec su -c "sh '$0'"
fi

echo "=== 创建酸败补丁目录结构 ==="
FAIL=0
for DIR in \
    "$MAIN_DIR" \
    "$MAIN_DIR/补丁存放位置（zip）" \
    "$MAIN_DIR/临时解压" \
    "$MAIN_DIR/操作日志" \
    "$MAIN_DIR/备份文件" \
    "$MAIN_DIR/备份文件/原版" \
    "$MAIN_DIR/补丁素材源文件" \
    "$MAIN_DIR/异常记录" \
    "$MAIN_DIR/打包补丁" \
    "$MAIN_DIR/打包补丁/待打包资源"
do
    if mkdir -p "$DIR" 2>/dev/null; then
        chmod 0775 "$DIR" 2>/dev/null
        echo "✓ $DIR"
    else
        echo "✗ 无法创建 $DIR"
        FAIL=$((FAIL+1))
    fi
done

echo "=== 验证 ==="
ls -ld "$MAIN_DIR"/* 2>/dev/null

if [ "$FAIL" -eq 0 ]; then
    echo "所有目录已就绪。"
else
    echo "有 $FAIL 个目录没建成，检查上面 ✗ 的项。"
fi
echo ""
if [ -t 0 ]; then echo "按回车关闭终端..."; read -r; fi
