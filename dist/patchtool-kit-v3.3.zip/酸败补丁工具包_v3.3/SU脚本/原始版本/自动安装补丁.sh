#!/system/bin/sh
# 自动安装补丁 · 日志留原目录 + /data临时区版（彻底解决断连）

# ========= 配置区（完全按你的路径） =========
PATCH_DIR="/storage/emulated/0/LvShu/酸败补丁/补丁存放位置（zip）"
# 临时解压区放在/data分区（稳定不炸）
TMP_DIR="/data/local/tmp/patch_tmp"
# 日志文件留在你原来的目录，方便查看
LOG_DIR="/storage/emulated/0/LvShu/酸败补丁/操作日志"
LOG_FILE="$LOG_DIR/install_$(date '+%Y%m%d_%H%M%S').log"
GAME_DIR="/storage/emulated/0/Android/data/com.jumpw.mobile300/files"

# ========= 初始化 =========
# 用ROOT创建/data临时区，清空旧文件
su -c "mkdir -p '$TMP_DIR' && rm -rf '$TMP_DIR'/*"
# 用ROOT创建日志目录，初始化日志文件
su -c "mkdir -p '$LOG_DIR' && echo > '$LOG_FILE'"

# 日志函数（只在终端打印，全程不写文件，最后一次性写入）
LOG() {
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    local line="[$timestamp] $1"
    LOG_BUFFER+="$line"$'\n'
    echo "$1"
}

# ========= 主流程 =========
LOG "脚本启动，正在查找补丁文件..."
LOG "补丁目录：$PATCH_DIR"

COUNT=0
for ZIP_FILE in "$PATCH_DIR"/*.zip; do
    if [ ! -e "$ZIP_FILE" ]; then
        LOG "! 未找到任何 .zip 补丁文件"
        break
    fi

    COUNT=$((COUNT+1))
    ZIP_NAME=$(basename "$ZIP_FILE")
    LOG ""
    LOG "====================================="
    LOG "=== 开始处理第 $COUNT 个补丁: $ZIP_NAME ==="
    LOG "====================================="

    # 1. 用ROOT解压到/data分区（稳定不炸）
    LOG ""
    LOG "▶ 解压补丁文件到/data分区..."
    su -c "unzip -o '$ZIP_FILE' -d '$TMP_DIR' >/dev/null 2>&1"
    if [ $? -eq 0 ]; then
        LOG "✓ 解压完成，文件已存到/data分区"
    else
        LOG "✗ 解压失败，跳过此补丁"
        su -c "rm -rf '$TMP_DIR'/*"
        continue
    fi

    # 2. 一次性部署所有文件（全程ROOT，只碰一次emulated/0）
    LOG ""
    LOG "▶ 一次性部署所有文件到游戏目录..."
    LOG "-------------------------------------"

    # 用ROOT执行部署，部署记录写到日志缓冲区
    DEPLOY_LOG=$(su -c "
        find '$TMP_DIR/files' -type f | while read -r SRC_FILE; do
            REL_PATH=\${SRC_FILE#$TMP_DIR/files/}
            DEST_PATH='$GAME_DIR'/\$REL_PATH
            DEST_DIR=\$(dirname \$DEST_PATH)
            mkdir -p \$DEST_DIR
            if cp -f \$SRC_FILE \$DEST_PATH; then
                echo \"✓ 成功部署: \$REL_PATH\"
                echo \"  目标目录: \$DEST_DIR\"
            else
                echo \"✗ 部署失败: \$REL_PATH\"
                echo \"  目标目录: \$DEST_DIR\"
            fi
        done
    ")

    # 把部署记录加入日志缓冲区
    LOG_BUFFER+="$DEPLOY_LOG"$'\n'
    # 同时在终端打印
    echo "$DEPLOY_LOG"

    LOG "-------------------------------------"
    LOG "▶ 此补丁处理完成"

    # 3. 清理/data分区临时文件
    LOG ""
    LOG "▶ 清理/data分区临时文件..."
    su -c "rm -rf '$TMP_DIR'/*"
    LOG "✓ 临时文件已清理"
done

# ========= 收尾：最后一次性写入日志 =========
LOG ""
LOG "====================================="
LOG "=== 所有补丁处理完毕！ ==="
LOG "====================================="
LOG "日志文件路径: $LOG_FILE"

# 全程只在这里写一次日志文件，避免过程中频繁IO
su -c "echo '$LOG_BUFFER' > '$LOG_FILE'"

echo ""
echo "按回车关闭终端..."
read -r