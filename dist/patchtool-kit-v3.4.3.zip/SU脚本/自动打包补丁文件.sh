#!/system/bin/sh
# ============================================================
# 酸败补丁 · SU 打包工具（修订版 v2）
# 权限模型不变：su 驱动。
# 改的是：支持命令行直接给路径（不用每题都手输）、zip 不存在时给明确提示、
#         中途 Ctrl-C 也不会留下 补丁素材源文件/tmp_* 垃圾。
# 用法：
#   su -c "sh 自动打包补丁文件.sh 'data/android/assetbundle/prefabs/heroes'"
# 不带参数就进入交互输入。
# ============================================================

PACK_DIR="/storage/emulated/0/LvShu/酸败补丁/打包补丁/待打包资源"
WORKSPACE="/storage/emulated/0/LvShu/酸败补丁/补丁素材源文件"
OUTPUT_DIR="/storage/emulated/0/LvShu/酸败补丁/补丁存放位置（zip）"
STAMP=$(date '+%Y%m%d_%H%M%S')
TMP_DIR="$WORKSPACE/tmp_$STAMP"
OUT_ZIP="$OUTPUT_DIR/补丁_$STAMP.zip"

if [ "$(id -u)" != "0" ]; then
    exec su -c "sh '$0' $*"
fi

cleanup() { rm -rf "$TMP_DIR"; }
trap cleanup EXIT INT TERM

if [ -z "$1" ]; then
    echo "=== 打包补丁（ZIP）==="
    echo "示例：data/android/assetbundle/texture/heropanel"
    echo "     /data/android/assetbundle/texture/heropanel"
    printf "➤ 输入要打进去的相对路径: "
    read USER_PATH
else
    USER_PATH="$1"
fi

# 路径消毒：不管粘进来的是绝对路径还是带 files/ 的，统一成 files/ 后面的相对路径
REL=$(echo "$USER_PATH" | sed -E '
  s|^/storage/emulated/0/Android/data/[^/]+/files/||;
  s|^/data/data/[^/]+/files/||;
  s|^/storage/emulated/0/||;
  s|^.*/files/||;
  s|^/||;
  s|/+|/|g;
  s|/$||;
')

[ -z "$REL" ] && { echo "! 路径无效：$USER_PATH"; exit 1; }

if [ ! -d "$PACK_DIR" ] || [ -z "$(ls -A "$PACK_DIR" 2>/dev/null)" ]; then
    echo "! 待打包资源为空：$PACK_DIR"
    echo "  先把要打包的文件放进去。"
    exit 2
fi

if ! command -v zip >/dev/null 2>&1; then
    echo "! 本机没有 zip 命令，无法打包。"
    echo "  可以改用 APP 里的「📦 打包「待打包资源」」按钮，或装一个带 zip 的终端。"
    exit 3
fi

mkdir -p "$TMP_DIR/files/$REL" || { echo "! 创建临时目录失败"; exit 4; }
case "$REL" in
    */) ;;
    *) REL="$REL/" ;;
esac

echo "正在导入资源 → files/$REL"
cp -rf "$PACK_DIR"/. "$TMP_DIR/files/$REL" || { echo "! 复制失败"; exit 5; }

mkdir -p "$OUTPUT_DIR"
( cd "$TMP_DIR" && zip -r -q "$OUT_ZIP" files/ ) || { echo "! 压缩失败"; exit 6; }

echo "✓ 打包完成"
echo "  压缩包：$OUT_ZIP"
echo "  内部路径：files/$REL"
echo "  大小：$(du -h "$OUT_ZIP" | awk '{print $1}')"
