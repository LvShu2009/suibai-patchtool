#!/system/bin/sh
# ============================================================
# 酸败补丁 · SU 自动安装（v3.13，对齐 APP v3.12）
#
# 只做 APP 在 root 通道下的等价实现，不再维护第二套规则：
#   1) 游戏目录不写死：--game 指定 > com.jumpw.* 自动探测 > 默认官服
#   2) 备份按包名隔离：备份文件/<包名>/原版/，索引 .manifest.tsv 三列
#      rel / cksum / size，与 APP 回滚脚本同一格式，APP 能直接回滚
#   3) 备份判定对齐 v3.8：看备份文件是否存在，不再用「内容相同就跳过」
#      （旧逻辑会让重装过的补丁永远没有原版可还原）
#   4) 说明/预览文件不进游戏：png/jpg/jpeg/md/txt 跳过，localmode.txt 例外
#   5) 资源定位：精确路径 → 逐级剥皮 → 同名唯一 → 同名多个按 CAB 32 位比对
#      带 files/ 根的包视为绝对路径包：包内路径第一优先级直装，不找同名/不猜
#      包内路径属于 data/android/assetbundle/ 时默认按路径写入（与旧版一致，
#      新增皮肤/语音这类资源不会因为「游戏里还没有」被跳过）；--strict 关闭
#   6) root 优先 /data/media/0：写前可写探测 + 三次重试 + 挂载点切换
#   7) 文件名编码：python3（按 UTF-8 标志 + GBK 试探）> unzip 默认 > unzip -O GBK > 扁平解压
#
# 用法：
#   su -c "sh 自动安装补丁.sh"
#   su -c "sh 自动安装补丁.sh --game /storage/emulated/0/Android/data/com.jumpw.mobile.aligames/files"
#   su -c "sh 自动安装补丁.sh --pkg com.jumpw.mobile.aligames"
#   su -c "sh 自动安装补丁.sh --zip 某个补丁.zip --dry-run"
# ============================================================

VERSION="SU 安装脚本 v3.13（对齐 APP v3.12）"

MAIN_PUB="/storage/emulated/0/LvShu/酸败补丁"
PATCH_PUB="$MAIN_PUB/补丁存放位置（zip）"

ROOTS="/data/media/0 /storage/emulated/0 /mnt/pass_through/0/emulated/0 /mnt/user/0/emulated/0"

DRY=0
NO_ELEVATE=0
ADD_NEW=1
REPAIR_INDEX=0
GAME_ARG=""
PKG_ARG=""
ZIP_ARG=""

usage() {
    cat <<EOF
$VERSION

用法：
  sh 自动安装补丁.sh [选项]

选项：
  --game <路径>   指定游戏 files 目录（默认自动探测 com.jumpw.*）
  --pkg <包名>    只指定包名，路径按默认卷展开
  --zip <文件>    只装指定 zip（默认装 补丁存放位置（zip）/*.zip）
  --dry-run       只打印将要做什么，不备份、不写游戏目录
  --strict        只装游戏里已有同路径/同名文件，不按包内路径新增（APP 的严格判定）
  --repair-index  先扫一遍备份目录：补写缺失索引、报告校验不符，然后正常安装
  --add-new       兼容旧参数；默认已开启，显式写上也不会改变行为
  --no-elevate    已经是 root / 调试用，不再自己调 su
  -h, --help      显示本帮助

示例：
  su -c "sh 自动安装补丁.sh"
  su -c "sh 自动安装补丁.sh --pkg com.jumpw.mobile.aligames"
EOF
}

# ---------- 参数 ----------
while [ $# -gt 0 ]; do
    case "$1" in
        --game)      GAME_ARG="$2"; shift 2 ;;
        --game=*)    GAME_ARG="${1#*=}"; shift ;;
        --pkg)       PKG_ARG="$2"; shift 2 ;;
        --pkg=*)     PKG_ARG="${1#*=}"; shift ;;
        --zip)       ZIP_ARG="$2"; shift 2 ;;
        --zip=*)     ZIP_ARG="${1#*=}"; shift ;;
        --dry-run)   DRY=1; shift ;;
        --add-new)   ADD_NEW=1; shift ;;
        --strict|--no-add-new) ADD_NEW=0; shift ;;
        --repair-index) REPAIR_INDEX=1; shift ;;
        --no-elevate) NO_ELEVATE=1; shift ;;
        -h|--help)   usage; exit 0 ;;
        --args-file)
            AF="$2"; shift 2
            set --
            while IFS= read -r _line; do
                set -- "$@" "$_line"
            done < "$AF"
            rm -f "$AF"
            ;;
        *)
            echo "✗ 不认识的参数：$1"
            usage
            exit 1
            ;;
    esac
done

# ---------- 自提权：只在开头 su 一次 ----------
# su -c 之后的命令由新 shell 解析，参数带空格/引号会被拆，所以把参数落成文件再传。
if [ "$(id -u)" != "0" ] && [ "$NO_ELEVATE" != "1" ]; then
    case "$0" in
        *"'"*)
            echo "✗ 脚本路径里含单引号，su 提权无法安全引用；请把脚本放到普通路径后重试"
            exit 1
            ;;
    esac
    AF="/data/local/tmp/.su_install_args.$$"
    : > "$AF" 2>/dev/null || {
        AF="${TMPDIR:-/tmp}/.su_install_args.$$"
        : > "$AF" || { echo "✗ 无法写参数临时文件"; exit 1; }
    }
    for arg in "$@"; do printf '%s\n' "$arg" >> "$AF"; done
    exec su -c "sh '$0' --args-file '$AF'"
fi

STAMP=$(date '+%Y%m%d_%H%M%S')

# 临时目录：/data/local/tmp 在部分机器/非 root 场景不可写，退到 $TMPDIR 或 /tmp
TMP_BASE="/data/local/tmp"
if ! mkdir -p "$TMP_BASE" 2>/dev/null || ! touch "$TMP_BASE/.w_test" 2>/dev/null; then
    TMP_BASE="${TMPDIR:-/tmp}"
fi
rm -f "$TMP_BASE/.w_test" 2>/dev/null

# ---------- 小工具 ----------
pkg_of() {
    case "$1" in
        */Android/data/*)
            _rest="${1#*/Android/data/}"
            printf '%s' "${_rest%%/*}"
            ;;
        *) printf '' ;;
    esac
}

strip_vol() {
    case "$1" in
        /data/media/0/*)                  printf '%s' "${1#/data/media/0/}" ;;
        /storage/emulated/0/*)            printf '%s' "${1#/storage/emulated/0/}" ;;
        /mnt/pass_through/0/emulated/0/*) printf '%s' "${1#/mnt/pass_through/0/emulated/0/}" ;;
        /mnt/user/0/emulated/0/*)         printf '%s' "${1#/mnt/user/0/emulated/0/}" ;;
        /storage/self/primary/*)          printf '%s' "${1#/storage/self/primary/}" ;;
        /sdcard/*)                        printf '%s' "${1#/sdcard/}" ;;
        *) printf '' ;;
    esac
}

detect_pkg() {
    _found=""
    for _base in /data/media/0/Android/data /storage/emulated/0/Android/data; do
        [ -d "$_base" ] || continue
        for _d in "$_base"/com.jumpw.*; do
            [ -d "$_d/files" ] || continue
            _p="${_d##*/}"
            case " $_found " in
                *" $_p "*) ;;
                *) _found="$_found $_p" ;;
            esac
        done
    done
    [ -n "$_found" ] || return 1
    # 官服优先，与 APP 默认值一致
    case " $_found " in
        *" com.jumpw.mobile300 "*)
            printf '%s' com.jumpw.mobile300
            return 0
            ;;
    esac
    set -- $_found
    printf '%s' "$1"
}

# ---------- 定位游戏目录与卷 ----------
GRELP=""
GAME_REL=""
if [ -n "$GAME_ARG" ]; then
    GRELP=$(strip_vol "$GAME_ARG")
    PKG=$(pkg_of "$GAME_ARG")
    [ -n "$PKG_ARG" ] && PKG="$PKG_ARG"
else
    PKG="$PKG_ARG"
    if [ -z "$PKG" ]; then
        PKG=$(detect_pkg) || PKG=""
    fi
    if [ -z "$PKG" ]; then
        PKG="com.jumpw.mobile300"
    fi
    GRELP="Android/data/$PKG/files"
    GAME_REL="$GRELP"
fi

# 备份相对路径：有包名按包名隔离，认不出包名才退回老的共享目录
if [ -n "$PKG" ]; then
    BK_REL="LvShu/酸败补丁/备份文件/$PKG/原版"
else
    BK_REL="LvShu/酸败补丁/备份文件/原版"
fi

ROOT=""
if [ -n "$GRELP" ]; then
    GAME_REL="$GRELP"
    for _c in $ROOTS; do
        [ -d "$_c/$GAME_REL" ] || continue
        if [ "$DRY" = "1" ]; then
            [ -w "$_c/$GAME_REL" ] || continue
        else
            touch "$_c/$GAME_REL/.w_test" 2>/dev/null || continue
            rm -f "$_c/$GAME_REL/.w_test" 2>/dev/null
        fi
        ROOT="$_c"
        break
    done
else
    # 路径不在已知卷下：按绝对路径处理，不做挂载点切换
    ROOT=""
fi

if [ -n "$ROOT" ]; then
    DST="$ROOT/$GAME_REL"
    MAIN="$ROOT/LvShu/酸败补丁"
    BK="$ROOT/$BK_REL"
else
    if [ -z "$GAME_ARG" ]; then
        echo "✗ 找不到游戏目录：$GRELP"
        echo "  先确认游戏已安装；渠道服用 --pkg 或 --game 指定。"
        exit 3
    fi
    DST="$GAME_ARG"
    PKG=$(pkg_of "$DST")
    MAIN="$MAIN_PUB"
    if [ -n "$PKG" ]; then
        BK_REL="LvShu/酸败补丁/备份文件/$PKG/原版"
        BK="$MAIN_PUB/备份文件/$PKG/原版"
    else
        BK_REL="LvShu/酸败补丁/备份文件/原版"
        BK="$MAIN_PUB/备份文件/原版"
    fi
    ROOTS=""
fi

if [ ! -d "$DST" ]; then
    echo "✗ 游戏目录不存在：$DST"
    exit 3
fi

# ---------- 旧备份归档：与 APP 的 backupOrig 同规则 ----------
LEGACY="$MAIN/备份文件/原版"
if [ -n "$PKG" ] && [ -d "$LEGACY" ] && [ ! -d "$BK" ] && [ "$DRY" != "1" ]; then
    mkdir -p "${BK%/*}" 2>/dev/null && mv "$LEGACY" "$BK" 2>/dev/null && \
        echo "ℹ 旧备份已归档到按包名分开的位置：$BK"
fi

# ---------- 日志 ----------
LOG_DIR="$MAIN/操作日志"
if ! mkdir -p "$LOG_DIR" 2>/dev/null; then
    LOG_DIR="$TMP_BASE"
    mkdir -p "$LOG_DIR" 2>/dev/null
fi
LOG_FILE="$LOG_DIR/install_su_$STAMP.log"
: > "$LOG_FILE" 2>/dev/null
chmod 0664 "$LOG_FILE" 2>/dev/null

LOG() {
    _t=$(date '+%Y-%m-%d %H:%M:%S')
    printf '[%s] %s\n' "$_t" "$*"
    printf '[%s] %s\n' "$_t" "$*" >> "$LOG_FILE" 2>/dev/null
}

# ---------- 并发锁 ----------
LOCK="$MAIN/.install_su.lock"
if [ "$DRY" != "1" ]; then
    if ! mkdir "$LOCK" 2>/dev/null; then
        _pid=$(cat "$LOCK/pid" 2>/dev/null)
        if [ -n "$_pid" ] && kill -0 "$_pid" 2>/dev/null; then
            echo "✗ 已有一个安装进程在跑（pid $_pid），本次退出"
            exit 9
        fi
        rm -rf "$LOCK" 2>/dev/null
        mkdir "$LOCK" 2>/dev/null || { echo "✗ 建不了锁目录：$LOCK"; exit 9; }
    fi
    echo $$ > "$LOCK/pid" 2>/dev/null
    trap 'rm -rf "$LOCK" 2>/dev/null' EXIT INT TERM
fi

# ---------- 补丁目录 ----------
PATCH_DIR=""
for _c in "$MAIN/补丁存放位置（zip）" "$PATCH_PUB"; do
    [ -d "$_c" ] && { PATCH_DIR="$_c"; break; }
done
if [ -z "$PATCH_DIR" ]; then
    LOG "✗ 补丁目录不存在：$MAIN/补丁存放位置（zip）"
    LOG "  先跑一次 创建所需文件夹.sh"
    exit 5
fi

LOG "=== $VERSION ==="
LOG "游戏目录：$DST"
LOG "补丁目录：$PATCH_DIR"
LOG "备份目录：${BK:-（无）}"
LOG "身份：uid=$(id -u)，卷：${ROOT:-绝对路径}"
[ "$DRY" = "1" ] && LOG "模式：dry-run（只打印，不写入）"

# ---------- 基础函数 ----------
mkd() { mkdir -p "$1" 2>/dev/null && return 0; sleep 0.4; mkdir -p "$1" 2>/dev/null && return 0; sleep 1; mkdir -p "$1" 2>/dev/null; }
put() { cp -f "$1" "$2" 2>/dev/null && return 0; sleep 0.4; cp -f "$1" "$2" 2>/dev/null && return 0; sleep 1; cp -f "$1" "$2" 2>/dev/null; }

cks() { cksum "$1" 2>/dev/null | awk '{print $1" "$2}'; }
look() { [ -n "$BKM" ] && [ -f "$BKM" ] || return 0; awk -F'\t' -v k="$1" '$1==k{print $2" "$3; exit}' "$BKM"; }
putmani() {
    [ -n "$BKM" ] || return 0
    awk -F'\t' -v k="$1" '$1!=k' "$BKM" 2>/dev/null > "$BKM.t" || : > "$BKM.t"
    printf '%s\t%s\t%s\n' "$1" "$2" "$3" >> "$BKM.t"
    mv -f "$BKM.t" "$BKM"
}

cab_of() { head -c 8192 "$1" 2>/dev/null | grep -a -m1 -o 'CAB-[0-9a-fA-F]\{32\}'; }

# 说明 / 预览文件不部署；localmode.txt 是游戏真需要的，例外
is_skip() {
    case "$1" in
        localmode.txt|*/localmode.txt) return 1 ;;
        *.png|*.PNG|*.jpg|*.JPG|*.jpeg|*.JPEG|*.md|*.MD|*.txt|*.TXT) return 0 ;;
    esac
    return 1
}

py_unzip() {
    python3 - "$1" "$2" <<'PY'
import os, sys, zipfile

z = zipfile.ZipFile(sys.argv[1])
out = sys.argv[2]
for i in z.infolist():
    n = i.filename
    # 没有 UTF-8 标志位的条目，Python 按 cp437 解；国内 Windows 打的包多是 GBK
    if not (i.flag_bits & 0x800):
        try:
            raw = n.encode('cp437')
            try:
                n = raw.decode('gbk')
            except UnicodeDecodeError:
                pass
        except UnicodeEncodeError:
            pass
    p = os.path.join(out, n)
    if i.is_dir():
        os.makedirs(p, exist_ok=True)
        continue
    d = os.path.dirname(p)
    if d:
        os.makedirs(d, exist_ok=True)
    with z.open(i) as s, open(p, 'wb') as f:
        while True:
            b = s.read(1 << 16)
            if not b:
                break
            f.write(b)
PY
}

UNZIP_MODE=""
FLAT=0
LAST_ERR=""
UNZIP_ERR=""

# 单次解压尝试：rc<=1 且确实解出了文件才算成功（Info-ZIP 用 1 表示有警告）
_zip_attempt() {
    _desc="$1"; shift
    : > "$UNZIP_ERR"
    "$@" >/dev/null 2>"$UNZIP_ERR"
    _rc=$?
    _n=$(find "$_DEST" -type f 2>/dev/null | wc -l | tr -d ' ')
    if [ "$_rc" -le 1 ] && [ "$_n" -gt 0 ]; then
        UNZIP_MODE="$_desc"
        return 0
    fi
    LAST_ERR=$(tail -n 2 "$UNZIP_ERR" 2>/dev/null | tr '\n' ' ')
    [ -z "$LAST_ERR" ] && LAST_ERR="rc=$_rc"
    return 1
}

extract_zip() {
    _ZIP="$1"; _DEST="$2"
    UNZIP_MODE=""; FLAT=0; LAST_ERR=""
    rm -rf "$_DEST"; mkdir -p "$_DEST" || return 1
    UNZIP_ERR="$TMP_BASE/.unzip_err.$$"
    # 只数文件条目：目录条目以 / 结尾，算进去会误报「只解出 1/104 个文件」
    _entries=$(unzip -l "$_ZIP" 2>/dev/null | awk '$1 ~ /^[0-9]+$/ && $4 != "" && $4 !~ /\/$/ {n++} END{print n+0}')

    # 1) python3 优先：它按 UTF-8 标志解码，GBK 包再做 cp437→GBK 试探，结果最可控
    if command -v python3 >/dev/null 2>&1; then
        if _zip_attempt "python3（UTF-8/GBK 试探）" py_unzip "$_ZIP" "$_DEST"; then
            rm -f "$UNZIP_ERR"
            return 0
        fi
        rm -rf "$_DEST"; mkdir -p "$_DEST"
    fi

    # 2) 没有 python3 时走系统 unzip 默认解码：toybox 对带 UTF-8 标志的包是正确的
    if _zip_attempt "unzip（默认解码）" unzip -o "$_ZIP" -d "$_DEST"; then
        _got=$(find "$_DEST" -type f 2>/dev/null | wc -l | tr -d ' ')
        if [ "$_entries" -gt 0 ] && [ "$_got" -lt "$_entries" ]; then
            LOG "⚠ 只解出 $_got/$_entries 个文件，包内可能有非法文件名"
        fi
        rm -f "$UNZIP_ERR"
        return 0
    fi
    rm -rf "$_DEST"; mkdir -p "$_DEST"

    # 3) 默认解不开（toybox 遇到 GBK 文件名常见），再上 GBK 解码（Info-ZIP 才有 -O）
    if _zip_attempt "unzip -O GBK" unzip -o -O GBK "$_ZIP" -d "$_DEST"; then
        rm -f "$UNZIP_ERR"
        return 0
    fi
    rm -rf "$_DEST"; mkdir -p "$_DEST"

    # 4) 扁平解压：只剩文件名。GBK 目录名解不开时，靠它把 ASCII 文件名救出来
    if _zip_attempt "unzip -j（扁平）" unzip -j -o "$_ZIP" -d "$_DEST"; then
        FLAT=1
        LOG "⚠ 目录名解不出来，改用扁平解压：只按文件名定位"
        rm -f "$UNZIP_ERR"
        return 0
    fi
    rm -rf "$_DEST"; mkdir -p "$_DEST"

    # 5) busybox 兜底：它的文件名解码不可靠，直接按「只认文件名」处理
    if command -v busybox >/dev/null 2>&1; then
        if _zip_attempt "busybox unzip -j（扁平）" busybox unzip -j -o "$_ZIP" -d "$_DEST"; then
            FLAT=1
            LOG "⚠ 系统 unzip 解不开，已用 busybox 扁平解压：只按文件名定位"
            rm -f "$UNZIP_ERR"
            return 0
        fi
        rm -rf "$_DEST"; mkdir -p "$_DEST"
        if _zip_attempt "busybox unzip" busybox unzip -o "$_ZIP" -d "$_DEST"; then
            FLAT=1
            LOG "⚠ 系统 unzip 解不开，已用 busybox 解压：按文件名定位，目录名可能不可用"
            rm -f "$UNZIP_ERR"
            return 0
        fi
        rm -rf "$_DEST"; mkdir -p "$_DEST"
    fi

    rm -f "$UNZIP_ERR"
    return 1
}

deploy_one() {
    _d="$2"
    mkd "${_d%/*}" || return 1
    put "$1" "$_d" || return 1
    [ -n "$OWNER" ] && chown "$OWNER" "$_d" 2>/dev/null
    chmod 0664 "$_d" 2>/dev/null
    command -v restorecon >/dev/null 2>&1 && restorecon "$_d" >/dev/null 2>&1
    return 0
}

switch_mount() {
    [ -n "$ROOTS" ] || return 1
    _old="$ROOT"
    for _c in $ROOTS; do
        [ "$_c" = "$_old" ] && continue
        [ -d "$_c/$GAME_REL" ] || continue
        if touch "$_c/$GAME_REL/.w_test" 2>/dev/null; then
            rm -f "$_c/$GAME_REL/.w_test" 2>/dev/null
            ROOT="$_c"
            DST="$ROOT/$GAME_REL"
            BK="$ROOT/$BK_REL"
            BKM="$BK/.manifest.tsv"
            LOG "↻ 挂载点已切换：$_c"
            return 0
        fi
    done
    return 1
}

# ---------- 写前自检 ----------
BKM=""
if [ -n "$BK" ]; then
    BKM="$BK/.manifest.tsv"
    if [ "$DRY" != "1" ]; then
        mkd "$BK" || LOG "⚠ 备份目录建不出来，本次跳过备份：$BK"
        if [ -d "$BK" ] && ! touch "$BK/.w_test" 2>/dev/null; then
            LOG "⚠ 备份目录不可写，本次跳过备份：$BK"
            BK=""; BKM=""
        else
            rm -f "$BK/.w_test" 2>/dev/null
        fi
    fi
fi

if [ "$DRY" != "1" ]; then
    if ! touch "$DST/.w_preflight" 2>/dev/null; then
        LOG "✗ 游戏目录当前不可写（挂载点失效），已中止，一个文件都没动：$DST"
        LOG "  处理：重启手机 / 重开终端后重试；root 应能走 /data/media/0"
        exit 7
    fi
    rm -f "$DST/.w_preflight" 2>/dev/null
fi

OWNER=$(stat -c '%u:%g' "$DST" 2>/dev/null)

# ---------- 游戏侧同名索引（一次建好，后面只做小表查询） ----------
IDX="$TMP_BASE/.patch_su_idx.$$"
rm -rf "$IDX"; mkdir -p "$IDX" || { LOG "✗ 建不了临时索引目录：$IDX"; exit 4; }
trap 'rm -rf "$LOCK" "$IDX" "$TMP_DIR" 2>/dev/null' EXIT INT TERM

find "$DST" -type f 2>/dev/null > "$IDX/.glist"
awk -F/ '{print $NF"\t"$0}' "$IDX/.glist" 2>/dev/null | sort > "$IDX/.bybase"
LOG "游戏侧文件：$(wc -l < "$IDX/.glist" | tr -d ' ') 个"



# 备份索引修复：补写缺失条目、报告校验不符与文件缺失（APP 回滚只认索引）
repair_index() {
    if [ -z "$BK" ] || [ ! -d "$BK" ]; then
        LOG "⚠ 没有备份目录，跳过索引修复"
        return 0
    fi
    LOG "=== 索引修复：$BK ==="
    _ok=0; _add=0; _bad=0; _miss=0
    find "$BK" -type f ! -name '.manifest.tsv' 2>/dev/null > "$IDX/.bklist"
    while IFS= read -r _f; do
        _rel="${_f#$BK/}"
        _have=$(look "$_rel")
        _cur=$(cks "$_f")
        if [ -z "$_have" ]; then
            if [ "$DRY" = "1" ]; then
                LOG "  [dry-run] 将补写索引：$_rel"
            else
                putmani "$_rel" $_cur
                LOG "  ℹ 补写索引：$_rel"
            fi
            _add=$((_add+1))
        elif [ "$_have" != "$_cur" ]; then
            _bad=$((_bad+1))
            LOG "  ⚠ 校验不符（保留原索引，回滚会跳过）：$_rel"
        else
            _ok=$((_ok+1))
        fi
    done < "$IDX/.bklist"

    if [ -f "$BKM" ]; then
        awk -F'\t' '{print $1}' "$BKM" > "$IDX/.bkidx" 2>/dev/null
        while IFS= read -r _rel; do
            [ -n "$_rel" ] || continue
            [ -f "$BK/$_rel" ] && continue
            _miss=$((_miss+1))
            LOG "  ⚠ 索引有、备份文件缺失：$_rel"
        done < "$IDX/.bkidx"
    fi
    LOG "索引修复完成：正常 $_ok，补写 $_add，校验不符 $_bad，文件缺失 $_miss"
}

# 函数定义完再调用，顺序反了会 command not found
[ "$REPAIR_INDEX" = "1" ] && repair_index

# ---------- 逐个 zip ----------
TMP_DIR="$TMP_BASE/patch_su_tmp"
ZIPS=0; FILES=0; OK=0; BAD=0; SKIP=0; BKOK=0; BKFAIL=0; WN=0

# 绝对路径条目归一：取第一个 files/ 之后的部分；不在 files/ 下返回 1
norm_abs() {
    case "$1" in
        files/*)     printf '%s' "${1#files/}" ;;
        *"/files/"*) printf '%s' "${1#*/files/}" ;;
        *) return 1 ;;
    esac
}

run_zip() {
    ZIP_FILE="$1"
    ZIP_NAME="${ZIP_FILE##*/}"
    ZIPS=$((ZIPS+1))
    LOG ""
    LOG "=== [$ZIPS] $ZIP_NAME ==="

    if ! extract_zip "$ZIP_FILE" "$TMP_DIR"; then
        LOG "✗ 解压失败，跳过"
        [ -n "$LAST_ERR" ] && LOG "  unzip 报错：$LAST_ERR"
        return 0
    fi

    SRC="$TMP_DIR"
    AUTH=0
    if [ "$FLAT" = "1" ]; then
        _pfx="扁平（仅文件名）"
    elif [ -d "$TMP_DIR/files" ]; then
        AUTH=1
        _pfx="files/（绝对路径）"
    else
        # 绝对路径包：/storage/.../files/、/data/media/0/.../files/、/sdcard/.../files/
        _nested=$(find "$TMP_DIR" -maxdepth 8 -type d -name files 2>/dev/null | head -n 1)
        if [ -n "$_nested" ]; then
            AUTH=1
            _pfx="files/（绝对路径，嵌套）"
        else
            _pfx="包根"
        fi
    fi
    LOG "解压完成（$UNZIP_MODE，根：$_pfx）"

    # 绝对路径包从解压根开始列条目，再逐条取 files/ 之后的部分：
    # 一个包里同时混了 /storage 与 /data/media 两种前缀也能各自落位
    ( cd "$TMP_DIR" 2>/dev/null && find . -type f 2>/dev/null | sed 's|^\./||' > "$IDX/.rels" )
    if [ ! -s "$IDX/.rels" ]; then
        LOG "⚠ 这个补丁一个文件都没部署：zip 里可能是空包"
        return 0
    fi
    awk -F/ '{print $NF}' "$IDX/.rels" 2>/dev/null | sort -u > "$IDX/.need"
    awk -F'\t' 'NR==FNR{need[$1]=1; next} ($1 in need)' \
        "$IDX/.need" "$IDX/.bybase" 2>/dev/null > "$IDX/.matches"

    while IFS= read -r REL; do
        [ -z "$REL" ] && continue
        ORIG_REL="$REL"
        if [ "$AUTH" = "1" ]; then
            REL=$(norm_abs "$ORIG_REL") || {
                LOG "  ⚠ 不在 files/ 下的条目，跳过：$ORIG_REL"
                SKIP=$((SKIP+1))
                continue
            }
            case "$ORIG_REL" in
                *..*)
                    LOG "  ⚠ 路径含 ..，拒绝写入：$ORIG_REL"
                    SKIP=$((SKIP+1))
                    continue
                    ;;
            esac
            case "$ORIG_REL" in
                *"/Android/data/"*)
                    _ep="${ORIG_REL#*/Android/data/}"
                    _ep="${_ep%%/*}"
                    if [ -n "$PKG" ] && [ "$_ep" != "$PKG" ]; then
                        LOG "  ⚠ 绝对路径属于其他包（$_ep），跳过：$ORIG_REL"
                        SKIP=$((SKIP+1))
                        continue
                    fi
                    ;;
            esac
            case "$REL" in
                *assets/android/assetbundle*)
                    LOG "  ⚠ 属于 APK 内置资源，热更目录装不了，跳过：$REL"
                    SKIP=$((SKIP+1))
                    continue
                    ;;
            esac
            SRC_FILE="$TMP_DIR/$ORIG_REL"
        else
            SRC_FILE="$SRC/$REL"
        fi
        [ -f "$SRC_FILE" ] || continue

        if is_skip "$REL"; then
            SKIP=$((SKIP+1))
            LOG "  - 跳过（说明/预览文件）$REL"
            continue
        fi

        FILES=$((FILES+1))
        : > "$IDX/.targets"

        # ① 绝对路径包：直接按 files/ 后的路径落位，不找同名、不比 CAB
        if [ "$AUTH" = "1" ]; then
            case "$REL" in
                *..*)
                    LOG "  ⚠ 路径含 ..，拒绝写入：$REL"
                    SKIP=$((SKIP+1))
                    continue
                    ;;
            esac
            printf '%s\n' "$DST/$REL" >> "$IDX/.targets"
        elif [ "${REL##*/}" = "localmode.txt" ]; then
            printf '%s\n' "$DST/localmode.txt" >> "$IDX/.targets"
        elif [ -f "$DST/$REL" ] && [ ! -d "$DST/$REL" ]; then
            printf '%s\n' "$DST/$REL" >> "$IDX/.targets"
        else
            # ② 逐级剥皮：李白/role/x.assetbundle → role/x.assetbundle → x.assetbundle
            _t="$REL"
            while :; do
                case "$_t" in
                    */*) _t="${_t#*/}" ;;
                    *) break ;;
                esac
                if [ -f "$DST/$_t" ] && [ ! -d "$DST/$_t" ]; then
                    printf '%s\n' "$DST/$_t" >> "$IDX/.targets"
                    break
                fi
            done
        fi

        # ③ 同名唯一 / ④ 同名多个 + CAB 双条件
        if [ ! -s "$IDX/.targets" ]; then
            _base="${REL##*/}"
            awk -F'\t' -v k="$_base" '$1==k{print $2}' "$IDX/.matches" > "$IDX/.cand"
            _cn=$(wc -l < "$IDX/.cand" | tr -d ' ')
            if [ "$_cn" = "1" ]; then
                head -n 1 "$IDX/.cand" >> "$IDX/.targets"
            elif [ "$_cn" -gt 1 ]; then
                case "$REL" in
                    *.assetbundle|*.ASSETBUNDLE)
                        _sc=$(cab_of "$SRC_FILE")
                        if [ -n "$_sc" ]; then
                            while IFS= read -r _c; do
                                [ "$(cab_of "$_c")" = "$_sc" ] && printf '%s\n' "$_c" >> "$IDX/.targets"
                            done < "$IDX/.cand"
                        fi
                        ;;
                esac
                if [ ! -s "$IDX/.targets" ]; then
                    LOG "  ⚠ 同名多个、CAB 对不上，跳过：$REL"
                    SKIP=$((SKIP+1))
                    continue
                fi
            fi
        fi

        # ⑤ 默认按包内路径新增：只认 data/android/assetbundle/，包装目录仍然不猜
        if [ ! -s "$IDX/.targets" ] && [ "$ADD_NEW" = "1" ]; then
            case "$REL" in
                data/android/assetbundle/*)
                    printf '%s\n' "$DST/$REL" >> "$IDX/.targets"
                    LOG "  + 按包内路径新增 $REL"
                    ;;
            esac
        fi

        if [ ! -s "$IDX/.targets" ]; then
            _cn_disp=$(wc -l < "$IDX/.cand" 2>/dev/null | tr -d ' ')
            [ -z "$_cn_disp" ] && _cn_disp=0
            LOG "  ⚠ 定位不到目标（同名候选 $_cn_disp 个），跳过：$REL"
            case "$REL" in
                *assets/android/assetbundle*)
                    LOG "    · 这属于 APK 内置资源，热更目录装不了，APP 也会跳过" ;;
                *)
                    if [ "$ADD_NEW" = "1" ]; then
                        LOG "    · 不是 data/android/assetbundle/ 路径，包装目录不猜；确认实际文件名后再处理"
                    else
                        LOG "    · 严格模式已跳过新增；去掉 --strict 可按包内 data 路径写入"
                    fi
                    ;;
            esac
            SKIP=$((SKIP+1))
            continue
        fi

        _any=0
        while IFS= read -r TGT; do
            DREL="${TGT#$DST/}"

            # 备份：v3.8 规则——备份文件不存在才备份，说明文件不备份
            case "$DREL" in
                *.txt|*.TXT|*.md|*.MD) _nobak=1 ;;
                *) _nobak=0 ;;
            esac
            if [ "$_nobak" = "0" ] && [ -n "$BK" ] && [ -f "$TGT" ] && [ ! -f "$BK/$DREL" ]; then
                case "$DREL" in
                    */*) _bd="$BK/${DREL%/*}" ;;
                    *) _bd="$BK" ;;
                esac
                if [ "$DRY" = "1" ]; then
                    LOG "  [dry-run] 将备份原版 $DREL"
                else
                    mkd "$_bd" 2>/dev/null
                    if put "$TGT" "$BK/$DREL"; then
                        putmani "$DREL" $(cks "$BK/$DREL")
                        BKOK=$((BKOK+1))
                        LOG "  已备份原版 $DREL"
                    else
                        BKFAIL=$((BKFAIL+1))
                        LOG "  ⚠ 备份失败（继续安装，但这个文件回滚时会缺原版）：$DREL"
                    fi
                fi
            elif [ "$_nobak" = "0" ] && [ -n "$BK" ] && [ -f "$BK/$DREL" ]; then
                _have=$(look "$DREL")
                if [ -z "$_have" ]; then
                    # 备份在、索引缺：补写一条，免得 APP 回滚时看不到
                    if [ "$DRY" != "1" ]; then
                        putmani "$DREL" $(cks "$BK/$DREL")
                        LOG "  ℹ 补写缺失索引：$DREL"
                    fi
                else
                    # 索引在，但和备份文件对不上：必须告警，不能装作没事
                    _cur=$(cks "$BK/$DREL")
                    if [ -n "$_cur" ] && [ "$_have" != "$_cur" ]; then
                        WN=$((WN+1))
                        LOG "  ⚠ 备份校验不符（保留原索引，APP 回滚会跳过）：$DREL"
                    fi
                fi
            fi

            if [ "$DRY" = "1" ]; then
                LOG "  [dry-run] 将写入 $DREL"
                _any=1
                continue
            fi

            if deploy_one "$SRC_FILE" "$TGT"; then
                _any=1
                LOG "  ✓ $DREL"
            elif switch_mount && deploy_one "$SRC_FILE" "$DST/$DREL"; then
                _any=1
                LOG "  ✓ $DREL（切换挂载点后成功）"
            else
                LOG "  ✗ $DREL（写入失败）"
            fi
        done < "$IDX/.targets"

        if [ "$_any" = "1" ]; then
            OK=$((OK+1))
        else
            BAD=$((BAD+1))
        fi
    done < "$IDX/.rels"

    rm -f "$IDX/.rels" "$IDX/.need" "$IDX/.matches" "$IDX/.targets" "$IDX/.cand"
}

if [ -n "$ZIP_ARG" ]; then
    if [ -f "$ZIP_ARG" ]; then
        ZIP_LIST="$ZIP_ARG"
    elif [ -f "$PATCH_DIR/$ZIP_ARG" ]; then
        ZIP_LIST="$PATCH_DIR/$ZIP_ARG"
    else
        LOG "✗ 找不到指定的 zip：$ZIP_ARG"
        exit 5
    fi
    run_zip "$ZIP_LIST"
else
    _found=0
    for f in "$PATCH_DIR"/*.zip; do
        [ -e "$f" ] || continue
        _found=1
        run_zip "$f"
    done
    if [ "$_found" = "0" ]; then
        LOG "! 补丁目录里没有 .zip：$PATCH_DIR"
    fi
fi

rm -rf "$TMP_DIR" "$IDX"
command -v sync >/dev/null 2>&1 && sync

LOG ""
LOG "=== 全部处理完毕：补丁 $ZIPS 个，可部署文件 $FILES 个，成功 $OK，失败 $BAD，跳过 $SKIP ==="
LOG "备份：新增 $BKOK 个，失败 $BKFAIL 个（${BK:-无}）"
[ "$WN" -gt 0 ] && LOG "⚠ 有 $WN 个文件的备份校验不符，回滚会跳过它们（详见上面日志）"
LOG "日志文件：$LOG_FILE"

if [ "$BAD" -gt 0 ]; then
    LOG "⚠ 有 $BAD 个文件没写进去（常见原因：挂载点中途失效）"
    exit 8
fi
exit 0