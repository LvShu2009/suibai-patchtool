#!/system/bin/sh
# ============================================================
# 酸败补丁 · SU 自动安装（修订版 v2）
# 权限模型没变：还是 su（root）驱动，不考虑权限访问问题。
# 只修了原始版本的逻辑问题：
#   1) zip 里没有 files/ 前缀时，原始版会静默部署 0 个文件 → 现在自动兼容并报警
#   2) 加了「覆盖前备份原版 + cksum 索引」，与 APP 共用 备份文件/原版/，APP 能一键回滚
#   3) 日志改成一跑就追加，中途崩也留得下；不再最后一次性 echo（单引号会截断命令）
#   4) 全程只在开头 su 一次自提权，后面不再层层 su -c，躲开引号地狱
# ============================================================

PATCH_DIR="/storage/emulated/0/LvShu/酸败补丁/补丁存放位置（zip）"
TMP_DIR="/data/local/tmp/patch_tmp"
LOG_DIR="/storage/emulated/0/LvShu/酸败补丁/操作日志"
GAME_DIR="/storage/emulated/0/Android/data/com.jumpw.mobile300/files"
BK_DIR="/storage/emulated/0/LvShu/酸败补丁/备份文件/原版"
STAMP=$(date '+%Y%m%d_%H%M%S')
LOG_FILE="$LOG_DIR/install_su_$STAMP.log"

# ---- 自提权：不是 root 就用 su 重新跑自己（本质还是 su） ----
if [ "$(id -u)" != "0" ]; then
    exec su -c "sh '$0'"
fi

mkdir -p "$LOG_DIR" "$BK_DIR" "$TMP_DIR"
: > "$LOG_FILE"
chmod 0664 "$LOG_FILE" 2>/dev/null

LOG() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*"
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" >> "$LOG_FILE"
}

cks()  { cksum "$1" 2>/dev/null | awk '{print $1" "$2}'; }
look() { awk -F'\t' -v k="$1" '$1==k{print $2" "$3; exit}' "$BK_DIR/.manifest.tsv" 2>/dev/null; }
putmani() {
    awk -F'\t' -v k="$1" '$1!=k' "$BK_DIR/.manifest.tsv" 2>/dev/null > "$BK_DIR/.manifest.t"
    printf '%s\t%s\t%s\n' "$1" "$2" "$3" >> "$BK_DIR/.manifest.t"
    mv "$BK_DIR/.manifest.t" "$BK_DIR/.manifest.tsv"
}

LOG "=== SU 自动安装开始 ==="
LOG "补丁目录：$PATCH_DIR"
LOG "游戏目录：$GAME_DIR"
LOG "备份目录：$BK_DIR"

[ -d "$GAME_DIR" ] || { LOG "✗ 游戏目录不存在，退出"; exit 3; }

TOTAL=0; OK=0; BAD=0; ZIPS=0
for ZIP_FILE in "$PATCH_DIR"/*.zip; do
    [ -e "$ZIP_FILE" ] || { LOG "! 补丁目录里没有 .zip"; break; }
    ZIP_NAME=${ZIP_FILE##*/}
    ZIPS=$((ZIPS+1))
    LOG ""
    LOG "=== [$ZIPS] $ZIP_NAME ==="

    rm -rf "$TMP_DIR"; mkdir -p "$TMP_DIR"
    if ! unzip -o "$ZIP_FILE" -d "$TMP_DIR" >/dev/null 2>&1; then
        LOG "✗ 解压失败，跳过"
        continue
    fi

    # 兼容两种包结构：带 files/ 前缀的用 files/，裸文件的用包根
    if [ -d "$TMP_DIR/files" ]; then SRC="$TMP_DIR/files"; MODE="files/ 前缀"; else SRC="$TMP_DIR"; MODE="裸文件包"; fi
    LOG "解压完成（结构：$MODE）"

    N=0
    find "$SRC" -type f 2>/dev/null | while IFS= read -r SRC_FILE; do
        REL=${SRC_FILE#$SRC/}
        [ -z "$REL" ] && continue
        DEST="$GAME_DIR/$REL"

        # 说明类文件不备份（它们不是游戏原版）
        case "$REL" in
            *.txt|*.TXT|*.md|*.MD) SKIPBAK=1 ;;
            *) SKIPBAK=0 ;;
        esac

        # 覆盖前备份原版：同一个文件只备份一次，靠 cksum 认，不靠文件名
        # 例外：目标文件和补丁内容一模一样 → 说明它本来就是补丁，不能当原版存
        if [ "$SKIPBAK" = "0" ] && [ -f "$DEST" ] && [ "$(cks "$DEST")" = "$(cks "$SRC_FILE")" ]; then
            LOG "  - $REL 与补丁内容相同，不备份（不是原版）"
            SKIPBAK=2
        fi
        if [ "$SKIPBAK" = "0" ] && [ -f "$DEST" ] && [ ! -f "$BK_DIR/$REL" ]; then
            mkdir -p "${BK_DIR}/${REL%/*}" 2>/dev/null
            if cp -f "$DEST" "$BK_DIR/$REL"; then
                putmani "$REL" $(cks "$BK_DIR/$REL")
                LOG "  已备份原版 $REL"
            fi
        elif [ "$SKIPBAK" = "0" ] && [ -f "$BK_DIR/$REL" ]; then
            HAVE=$(look "$REL"); CUR=$(cks "$BK_DIR/$REL")
            if [ -n "$HAVE" ] && [ "$HAVE" != "$CUR" ]; then
                LOG "  ⚠ 备份校验不符（疑似同名顶替），不改索引: $REL"
            fi
        fi

        mkdir -p "${DEST%/*}" 2>/dev/null
        if cp -f "$SRC_FILE" "$DEST"; then
            chown "$(stat -c '%u:%g' "$GAME_DIR")" "$DEST" 2>/dev/null
            chmod 0664 "$DEST" 2>/dev/null
            LOG "  ✓ $REL"
            OK=$((OK+1))
        else
            LOG "  ✗ $REL（写入失败）"
            BAD=$((BAD+1))
        fi
        TOTAL=$((TOTAL+1))
    done

    # while 在子 shell 里跑，计数拿回来要重新数一遍
    CNT=$(find "$SRC" -type f 2>/dev/null | wc -l | tr -d ' ')
    if [ "$CNT" = "0" ]; then
        LOG "⚠ 这个补丁一个文件都没部署：zip 里可能没有 files/ 目录结构"
    fi
    rm -rf "$TMP_DIR"
done

# 最终统计（重新数这次日志里的成功/失败行，避免子 shell 计数丢失）
OK=$(grep -c '  ✓ ' "$LOG_FILE" 2>/dev/null); [ -z "$OK" ] && OK=0
BAD=$(grep -c '  ✗ ' "$LOG_FILE" 2>/dev/null); [ -z "$BAD" ] && BAD=0
TOTAL=$((OK+BAD))
LOG ""
LOG "=== 全部处理完毕：补丁 $ZIPS 个，文件 $TOTAL 个，成功 $OK，失败 $BAD ==="
LOG "日志文件：$LOG_FILE"
echo ""
if [ -t 0 ]; then echo "按回车关闭终端..."; read -r; fi
