#!/system/bin/sh
# 功能：强制创建完整酸败补丁目录结构（含基础目录和所有子目录）

# 核心路径
MAIN_DIR="/storage/emulated/0/LvShu/酸败补丁"
PACK_DIR="$MAIN_DIR/打包补丁"

# 全量目录列表（已包含您要求的所有路径）
DIRS_TO_CREATE=(
  "$MAIN_DIR"
  "$MAIN_DIR/补丁存放位置（zip）"
  "$MAIN_DIR/临时解压"
  "$MAIN_DIR/操作日志" 
  "$MAIN_DIR/备份文件"
  "$MAIN_DIR/补丁素材源文件"
  "$MAIN_DIR/异常记录"
  "$PACK_DIR"              # 专门存放打包补丁的目录
  "$PACK_DIR/待打包资源"   # 需要打包的原始文件放这里
)

# 创建所有目录（强制模式）
echo "=== 正在创建酸败补丁生态目录 ==="
for DIR in "${DIRS_TO_CREATE[@]}"; do
  if mkdir -m 755 -p "$DIR"; then
    echo "✓ $DIR"
  else
    echo "✗ 致命错误：无法创建 $DIR"
    exit 1
  fi
done

# 验证结果
echo "=== 目录结构验证 ==="
ls -ld "$MAIN_DIR" "$PACK_DIR"
tree "$MAIN_DIR" -L 2 || ls -lR "$MAIN_DIR"

echo "所有目录已就绪！"