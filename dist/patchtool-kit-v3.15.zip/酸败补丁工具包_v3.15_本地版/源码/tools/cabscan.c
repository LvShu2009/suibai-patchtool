/*
 * cabscan.c —— 酸败补丁助手 CAB 索引扫描器（单进程）
 *
 * 用途：一次进程启动完成「递归目录 → 只读前 8KB → 找 CAB- 32 位十六进制 → 写 tsv」，
 * 替代原先每个文件 fork 两次 head|grep 的 shell 管线。
 *
 * 输出格式必须与旧脚本逐行等价：`CAB-xxxx(32位hex)\t文件绝对路径`
 *   • CAB 原样大小写，不做归一化（readCabTsv 与补丁侧 cabOfFile 都按原样比）
 *   • 严格 32 位，第 33 位也是 hex 时不再多吃（v3.12.1 踩过贪婪匹配的坑）
 *   • 只读前 8192 字节（toybox awk 会把几十 MB 读全，慢得多）
 *
 * 退出码：0 正常；2 参数/打开输出失败；3 命中数远小于文件数（防静默截断）；4 扫描根都不存在
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <dirent.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <time.h>

#define HEAD_BYTES 8192
#define HEX_N 32

static long n_total = 0;
static long n_hit = 0;
static long n_openfail = 0;

static int is_hex(char c) {
    return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');
}

static int has_ab_suffix(const char *name) {
    size_t l = strlen(name);
    if (l <= 13) return 0;                       /* ".assetbundle" 13 字节 */
    return strcasecmp(name + l - 12, ".assetbundle") == 0;
}

/* 读前 8KB，取第一处 CAB- + 精确 32 位 hex；成功写 37 字节（含结尾 0）。 */
static int cab_of(const char *path, char out[4 + HEX_N + 1]) {
    int fd = open(path, O_RDONLY);
    if (fd < 0) { n_openfail++; return 0; }

    static char buf[HEAD_BYTES];
    ssize_t n = 0;
    while (n < HEAD_BYTES) {
        ssize_t r = read(fd, buf + n, (size_t)(HEAD_BYTES - n));
        if (r <= 0) break;
        n += r;
    }
    close(fd);

    if (n < 4 + HEX_N) return 0;
    for (ssize_t i = 0; i <= n - (4 + HEX_N); ++i) {
        if (buf[i] != 'C' || buf[i + 1] != 'A' || buf[i + 2] != 'B' || buf[i + 3] != '-') continue;
        int ok = 1;
        for (int j = 0; j < HEX_N; ++j) {
            if (!is_hex(buf[i + 4 + j])) { ok = 0; break; }
        }
        if (ok) {
            memcpy(out, buf + i, 4 + HEX_N);
            out[4 + HEX_N] = '\0';
            return 1;
        }
    }
    return 0;
}

static void scan_dir(const char *dir, FILE *out) {
    DIR *d = opendir(dir);
    if (!d) return;

    struct dirent *e;
    while ((e = readdir(d)) != NULL) {
        if (e->d_name[0] == '.') continue;        /* 跳过 . / .. / 隐藏项 */

        size_t len = strlen(dir) + strlen(e->d_name) + 2;
        char *full = (char *)malloc(len);
        if (!full) continue;
        snprintf(full, len, "%s/%s", dir, e->d_name);

        struct stat st;
        if (lstat(full, &st) == 0) {              /* lstat：不跟随符号链接，避免环 */
            if (S_ISDIR(st.st_mode)) {
                scan_dir(full, out);
            } else if (S_ISREG(st.st_mode) && has_ab_suffix(e->d_name)) {
                n_total++;
                char cab[4 + HEX_N + 1];
                if (cab_of(full, cab)) {
                    fprintf(out, "%s\t%s\n", cab, full);
                    n_hit++;
                }
                if ((n_total % 2000) == 0) {
                    fprintf(stderr, "[cabscan] %ld files, %ld hit\n", n_total, n_hit);
                }
            }
        }
        free(full);
    }
    closedir(d);
}

int main(int argc, char **argv) {
    /* 用法: cabscan <输出tsv> <扫描根1> [扫描根2 ...] */
    if (argc < 3) {
        fprintf(stderr, "usage: cabscan OUT root1 [root2 ...]\n");
        return 2;
    }

    FILE *out = fopen(argv[1], "w");
    if (!out) {
        fprintf(stderr, "[cabscan] open out failed: %s\n", argv[1]);
        return 2;
    }

    int roots = 0;
    for (int i = 2; i < argc; ++i) {
        struct stat st;
        if (stat(argv[i], &st) == 0 && S_ISDIR(st.st_mode)) {
            scan_dir(argv[i], out);
            roots++;
        } else {
            fprintf(stderr, "[cabscan] skip (not dir): %s\n", argv[i]);
        }
    }

    fflush(out);
    fclose(out);

    if (roots == 0) {
        fprintf(stderr, "[cabscan] no scan root\n");
        return 4;
    }

    fprintf(stderr, "[cabscan] done total=%ld hit=%ld openfail=%ld\n",
            n_total, n_hit, n_openfail);

    /* 完整性保险：命中数不应远小于文件总数（对应旧脚本的 GOT/TOTAL 校验） */
    if (n_total > 1000 && n_hit * 2 < n_total) {
        fprintf(stderr, "[cabscan] WARN hit=%ld < total/2=%ld\n", n_hit, n_total / 2);
        return 3;
    }
    return 0;
}