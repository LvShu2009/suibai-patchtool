#!/system/bin/sh
# ============================================================
# 酸败补丁 · SU 打包（v3.13，对齐 APP v3.13）
#
# 把 打包补丁/待打包资源/ 里的东西打成标准补丁 zip：
#   内部路径固定 files/<相对路径>/…
# 与 APP 的「📦 打包」按钮产物完全同构，装的时候不会因为少了 files/ 前缀白跑。
#
# 相对路径会先消毒：去掉 files/、卷前缀、开头/结尾的 /，
# 并且拒绝 .. 段，避免以 root 身份把东西写到临时目录之外。
#
# 用法：
#   su -c "sh 自动打包补丁文件.sh data/android/assetbundle/prefabs/heroes"
#   su -c "sh 自动打包补丁文件.sh"              # 交互输入
# ============================================================

VERSION="SU 打包脚本 v3.13（对齐 APP v3.13）"

MAIN_PUB="/storage/emulated/0/LvShu/酸败补丁"
PACK_DIR="$MAIN_PUB/打包补丁/待打包资源"
WORKSPACE="$MAIN_PUB/补丁素材源文件"
OUTPUT_DIR="$MAIN_PUB/补丁存放位置（zip）"

REL_ARG=""
OUT_ARG=""
NO_ELEVATE=0

usage() {
    cat <<EOF
$VERSION

用法：
  sh 自动打包补丁文件.sh [相对路径] [选项]

参数：
  相对路径      要打进去的路径，例如 data/android/assetbundle/prefabs/heroes
                （可以粘绝对路径或带 files/ 的路径，脚本会自动剥掉前缀）

选项：
  --rel <路径>   同上，显式写法
  --out <文件>   指定输出 zip（默认 补丁存放位置（zip）/补丁_<时间>.zip）
  --no-elevate   已经是 root / 调试用，不再自己调 su
  -h, --help     显示本帮助

示例：
  su -c "sh 自动打包补丁文件.sh data/android/assetbundle/texture/heropanel"
  su -c "sh 自动打包补丁文件.sh --rel data/android/assetbundle --out 我的补丁.zip"
EOF
}

while [ $# -gt 0 ]; do
    case "$1" in
        --rel)        REL_ARG="$2"; shift 2 ;;
        --rel=*)      REL_ARG="${1#*=}"; shift ;;
        --out)        OUT_ARG="$2"; shift 2 ;;
        --out=*)      OUT_ARG="${1#*=}"; shift ;;
        --no-elevate) NO_ELEVATE=1; shift ;;
        -h|--help)    usage; exit 0 ;;
        --args-file)
            AF="$2"; shift 2
            set --
            while IFS= read -r _line; do
                set -- "$@" "$_line"
            done < "$AF"
            rm -f "$AF"
            ;;
        -*)
            echo "✗ 不认识的参数：$1"
            usage
            exit 1
            ;;
        *)
            if [ -z "$REL_ARG" ]; then
                REL_ARG="$1"; shift
            else
                echo "✗ 多余参数：$1"
                usage
                exit 1
            fi
            ;;
    esac
done

# ---------- 自提权 ----------
if [ "$(id -u)" != "0" ] && [ "$NO_ELEVATE" != "1" ]; then
    case "$0" in
        *"'"*)
            echo "✗ 脚本路径里含单引号，su 提权无法安全引用；请把脚本放到普通路径后重试"
            exit 1
            ;;
    esac
    AF="${TMPDIR:-/tmp}/.su_pack_args.$$"
    : > "$AF" 2>/dev/null || { echo "✗ 无法写参数临时文件"; exit 1; }
    for arg in "$@"; do printf '%s\n' "$arg" >> "$AF"; done
    exec su -c "sh '$0' --args-file '$AF'"
fi

STAMP=$(date '+%Y%m%d_%H%M%S')

# ---------- 相对路径消毒 ----------
sanitize_rel() {
    _r="$1"
    # 剥常见前缀：绝对卷路径 / 带 files/ 的路径
    case "$_r" in
        */files/*) _r="${_r##*/files/}" ;;
        files/*)   _r="${_r#files/}" ;;
    esac
    case "$_r" in
        /storage/emulated/0/*) _r="${_r#/storage/emulated/0/}" ;;
        /data/media/0/*)       _r="${_r#/data/media/0/}" ;;
        /sdcard/*)             _r="${_r#/sdcard/}" ;;
    esac
    # 去开头/结尾的 /，折叠空段，拒绝 .. 段
    _out=""
    _oldifs="$IFS"
    IFS='/'
    set -- $_r
    IFS="$_oldifs"
    for _seg in "$@"; do
        case "$_seg" in
            ''|.) continue ;;
            ..)   return 1 ;;
        esac
        _out="${_out}${_out:+/}${_seg}"
    done
    [ -n "$_out" ] || return 1
    printf '%s' "$_out"
}

if [ -z "$REL_ARG" ]; then
    echo "=== 打包补丁（ZIP）==="
    echo "示例：data/android/assetbundle/texture/heropanel"
    printf "➤ 输入要打进去的相对路径: "
    read -r REL_ARG
fi

REL=$(sanitize_rel "$REL_ARG") || {
    echo "✗ 路径无效（空路径或含 ..）：$REL_ARG"
    exit 1
}

# ---------- 环境检查 ----------
if [ ! -d "$PACK_DIR" ]; then
    echo "✗ 待打包目录不存在：$PACK_DIR"
    echo "  先跑一次 创建所需文件夹.sh，再把资源放进去。"
    exit 2
fi
if [ -z "$(ls -A "$PACK_DIR" 2>/dev/null)" ]; then
    echo "✗ 待打包资源为空：$PACK_DIR"
    echo "  先把要打包的文件放进去。"
    exit 2
fi

if ! command -v zip >/dev/null 2>&1; then
    echo "✗ 本机没有 zip 命令，无法打包。"
    echo "  可以改用 APP 里的「📦 打包「待打包资源」」按钮，或装一个带 zip 的终端。"
    exit 3
fi

mkdir -p "$OUTPUT_DIR" 2>/dev/null || { echo "✗ 建不了输出目录：$OUTPUT_DIR"; exit 4; }
if [ -n "$OUT_ARG" ]; then
    case "$OUT_ARG" in
        */*) OUT_ZIP="$OUT_ARG" ;;
        *)   OUT_ZIP="$OUTPUT_DIR/$OUT_ARG" ;;
    esac
else
    OUT_ZIP="$OUTPUT_DIR/补丁_$STAMP.zip"
fi

# ---------- 并发锁 ----------
LOCK="$MAIN_PUB/.pack_su.lock"
if ! mkdir "$LOCK" 2>/dev/null; then
    _pid=$(cat "$LOCK/pid" 2>/dev/null)
    if [ -n "$_pid" ] && kill -0 "$_pid" 2>/dev/null; then
        echo "✗ 已有一个打包进程在跑（pid $_pid），本次退出"
        exit 9
    fi
    rm -rf "$LOCK" 2>/dev/null
    mkdir "$LOCK" 2>/dev/null || { echo "✗ 建不了锁目录：$LOCK"; exit 9; }
fi
echo $$ > "$LOCK/pid" 2>/dev/null

TMP_DIR="$WORKSPACE/tmp_$STAMP"
cleanup() {
    rm -rf "$TMP_DIR" "$LOCK" 2>/dev/null
}
trap cleanup EXIT INT TERM

# ---------- 组装并压缩 ----------
mkdir -p "$TMP_DIR/files/$REL" || { echo "✗ 建临时目录失败：$TMP_DIR"; exit 4; }

echo "正在导入资源 → files/$REL"
cp -rf "$PACK_DIR"/. "$TMP_DIR/files/$REL/" || { echo "✗ 复制失败"; exit 5; }

N=$(find "$TMP_DIR/files" -type f 2>/dev/null | wc -l | tr -d ' ')
if [ "$N" = "0" ]; then
    echo "✗ 待打包目录里没有文件"
    exit 5
fi

( cd "$TMP_DIR" && zip -r -q "$OUT_ZIP" files/ ) || { echo "✗ 压缩失败"; exit 6; }

if [ ! -s "$OUT_ZIP" ]; then
    echo "✗ 压缩包没生成或为空：$OUT_ZIP"
    exit 6
fi

# 校验内部结构，避免打出一个装不进去的包
if command -v unzip >/dev/null 2>&1; then
    if ! unzip -l "$OUT_ZIP" 2>/dev/null | grep -q "files/$REL/"; then
        echo "⚠ 压缩包里没看到 files/$REL/，请检查资源目录"
    fi
fi

echo "✓ 打包完成"
echo "  压缩包：$OUT_ZIP"
echo "  内部路径：files/$REL/"
echo "  文件数：$N"
echo "  大小：$(du -h "$OUT_ZIP" 2>/dev/null | awk '{print $1}')"
exit 0