#!/system/bin/sh
# 强制标准化路径的打包工具（ZIP版）

# 配置区
PACK_DIR="/storage/emulated/0/LvShu/酸败补丁/打包补丁/待打包资源"
TMP_WORKSPACE="/storage/emulated/0/LvShu/酸败补丁/补丁素材源文件"
OUTPUT_DIR="/storage/emulated/0/LvShu/酸败补丁"
DATE=$(date '+%Y%m%d_%H%M%S')

# 初始化临时目录
TMP_DIR="$TMP_WORKSPACE/tmp_$DATE"
mkdir -p "$TMP_DIR/files" || {
  echo "! 无法创建工作目录"
  exit 1
}

# 用户输入提示
echo ""
echo "=== 绝对路径消毒打包工具（ZIP版）==="
echo "示例有效输入："
echo "1. data/android/assetbundle/texture/heropanel"
echo "2. /data/android/assetbundle/texture/heropanel"
echo "3. /storage/.../files/data/android/..."
echo ""
printf "➤ 输入路径: "
read USER_PATH

# 强力路径消毒
RELATIVE_PATH=$(echo "$USER_PATH" | sed -E '
  s|^/storage/emulated/0/Android/data/[^/]+/files/||;
  s|^/data/data/[^/]+/files/||;
  s|^.*/files/||;
  s|^/||;
  s|/+|/|g;
  s|/$||;
')

# 验证路径有效性
if [ -z "$RELATIVE_PATH" ]; then
  echo "! 路径无效：$USER_PATH"
  rm -rf "$TMP_DIR"
  exit 1
fi

# 构建文件结构
echo "正在创建标准路径..."
mkdir -p "$TMP_DIR/files/$RELATIVE_PATH" || {
  echo "! 无法创建目标路径"
  rm -rf "$TMP_DIR"
  exit 1
}

# 复制文件
echo "正在导入资源..."
if cp -r "$PACK_DIR"/* "$TMP_DIR/files/$RELATIVE_PATH/"; then
  (
    cd "$TMP_DIR" && \
    zip -r "$OUTPUT_DIR/补丁_$DATE.zip" files/ && \
    echo "✓ 打包成功！" && \
    echo "压缩包路径: $OUTPUT_DIR/补丁_$DATE.zip" && \
    echo "标准内部路径: files/$RELATIVE_PATH/"
  ) || echo "! 压缩失败"
else
  echo "! 文件复制失败"
fi

# 彻底清理
rm -rf "$TMP_DIR"
echo "操作完成"
